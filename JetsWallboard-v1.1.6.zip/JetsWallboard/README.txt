JET'S WALLBOARD v1.1.6

Double-click JetsWallboard.exe. The board opens in its own Edge window.
If Windows says "Windows protected your PC", click More info > Run anyway.

First run: search for your town in Settings > Location and click Save location.
Full screen: the corner-arrows button in the bottom bar, or press F.
Options (start with Windows, full screen, phones/tablets) and updates:
gear > Board.
